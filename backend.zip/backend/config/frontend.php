<?php

return [
    'url' => env('FRONTEND_URL', 'http://localhost:5173'),
]; 