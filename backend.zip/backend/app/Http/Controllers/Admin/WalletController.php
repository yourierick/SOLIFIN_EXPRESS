<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Wallet;
use App\Models\WalletSystem;
use App\Models\WalletSystemTransaction;
use App\Models\WalletTransaction;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Notifications\FundsTransferred;
use Illuminate\Support\Facades\DB;

class WalletController extends Controller
{
    public function getWalletData(Request $request)
    {
        try {
            // Récupérer les paramètres de pagination et de filtre
            $page = $request->get('page', 1);
            $perPage = $request->get('per_page', 25);
            $currency = $request->get('currency', 'USD');
            $status = $request->get('status', 'all');
            $type = $request->get('type', 'all');
            $search = $request->get('search', '');
            $startDate = $request->get('start_date', '');
            $endDate = $request->get('end_date', '');
            
            // Valider les paramètres
            $page = max(1, (int) $page);
            $perPage = in_array($perPage, [10, 25, 50, 100]) ? $perPage : 25;
            $currency = in_array($currency, ['USD', 'CDF']) ? $currency : 'USD';

            // Récupérer le wallet de l'admin connecté
            $userWallet = Wallet::where('user_id', Auth::id())->first();
            
            $adminWallet = $userWallet ? [
                'id' => $userWallet->id,
                'balance_usd' => $userWallet->balance_usd,
                'balance_cdf' => $userWallet->balance_cdf,
                'total_earned_usd' => $userWallet->total_earned_usd,
                'total_earned_cdf' => $userWallet->total_earned_cdf,
                'total_withdrawn_usd' => $userWallet->total_withdrawn_usd,
                'total_withdrawn_cdf' => $userWallet->total_withdrawn_cdf,
                'user' => $userWallet->user
            ] : null;
                
            $adminTransactionsQuery = WalletTransaction::with('wallet')
                ->where('wallet_id', $userWallet->id)
                ->where('currency', $currency);

            // Appliquer les filtres
            if ($status && $status !== 'all') {
                $adminTransactionsQuery->where('status', $status);
            }

            if ($type && $type !== 'all') {
                $adminTransactionsQuery->where('type', $type);
            }

            if ($search) {
                $adminTransactionsQuery->where(function($query) use ($search) {
                    $query->where('id', 'like', '%' . $search . '%')
                          ->orWhere('type', 'like', '%' . $search . '%')
                          ->orWhere('status', 'like', '%' . $search . '%')
                          ->orWhere('amount', 'like', '%' . $search . '%')
                          ->orWhere('reference', 'like', '%' . $search . '%');
                });
            }

            if ($startDate) {
                $adminTransactionsQuery->whereDate('created_at', '>=', $startDate);
            }

            if ($endDate) {
                $adminTransactionsQuery->whereDate('created_at', '<=', $endDate);
            }

            $totalAdminTransactions = $adminTransactionsQuery->count();

            // Récupérer les transactions du wallet admin avec pagination
            $adminwallettransactions = $adminTransactionsQuery
                ->orderBy('created_at', 'desc')
                ->paginate($perPage, ['*'], 'page', $page)
                ->map(function ($transaction) {
                    return [
                        'id' => $transaction->id,
                        'amount' => $transaction->amount,
                        'reference' => $transaction->reference,
                        'mouvment' => $transaction->mouvment,
                        'currency' => $transaction->currency,
                        'type' => $transaction->type,
                        'status' => $transaction->status,
                        'metadata' => $transaction->metadata,   
                        'created_at' => $transaction->created_at->format('d/m/Y H:i:s')
                    ];
                });

            return response()->json([
                'success' => true,
                'adminWallet' => $adminWallet,
                'adminwallettransactions' => $adminwallettransactions,
                'totalAdminTransactions' => $totalAdminTransactions,
                'pagination' => [
                    'current_page' => $page,
                    'per_page' => $perPage,
                    'currency' => $currency,
                    'filters' => [
                        'status' => $status,
                        'type' => $type,
                        'search' => $search,
                        'start_date' => $startDate,
                        'end_date' => $endDate
                    ]
                ]
            ]);
        } catch (\Exception $e) {
            \Log::error($e->getMessage());
            \Log::error($e->getTraceAsString());
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération des données',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Exporter toutes les transactions du portefeuille admin
     */
    public function exportAdminTransactions(Request $request)
    {
        try {
            // Récupérer les paramètres de filtrage
            $currency = $request->input('currency', 'USD');
            $status = $request->input('status', 'all');
            $type = $request->input('type', 'all');
            $search = $request->input('search', '');
            $startDate = $request->input('start_date', '');
            $endDate = $request->input('end_date', '');

            // Récupérer l'utilisateur administrateur et son portefeuille
            $admin = auth()->user();
            $adminWallet = Wallet::where('user_id', $admin->id)->first();

            if (!$adminWallet) {
                return response()->json([
                    'success' => false,
                    'message' => 'Portefeuille administrateur non trouvé'
                ], 404);
            }

            // Construire la requête pour les transactions admin
            $query = WalletTransaction::with(['wallet.user'])
                ->where('wallet_id', $adminWallet->id)
                ->where('currency', $currency);

            // Appliquer les filtres
            if ($status !== 'all') {
                $query->where('status', $status);
            }

            if ($type !== 'all') {
                $query->where('type', $type);
            }

            if (!empty($search)) {
                $query->where(function($q) use ($search) {
                    $q->where('id', 'like', '%' . $search . '%')
                      ->orWhere('type', 'like', '%' . $search . '%')
                      ->orWhere('status', 'like', '%' . $search . '%')
                      ->orWhere('amount', 'like', '%' . $search . '%')
                      ->orWhere('reference', 'like', '%' . $search . '%');
                });
            }

            if (!empty($startDate)) {
                $query->whereDate('created_at', '>=', $startDate);
            }

            if (!empty($endDate)) {
                $query->whereDate('created_at', '<=', $endDate);
            }

            // Récupérer TOUTES les transactions (sans pagination)
            $transactions = $query->orderBy('created_at', 'desc')->get();

            // Formater les transactions
            $formattedTransactions = $transactions->map(function ($transaction) {
                return [
                    'id' => $transaction->id,
                    'amount' => $transaction->amount,
                    'reference' => $transaction->reference,
                    'mouvment' => $transaction->mouvment,
                    'currency' => $transaction->currency,
                    'type' => $transaction->type,
                    'status' => $transaction->status,
                    'metadata' => $transaction->metadata,
                    'created_at' => $transaction->created_at->format('d/m/Y H:i:s')
                ];
            });

            return response()->json([
                'success' => true,
                'transactions' => $formattedTransactions,
                'total' => $formattedTransactions->count(),
                'currency' => $currency,
                'wallet_type' => 'admin',
                'filters' => [
                    'status' => $status,
                    'type' => $type,
                    'search' => $search,
                    'start_date' => $startDate,
                    'end_date' => $endDate
                ]
            ]);

        } catch (\Exception $e) {
            \Log::error($e->getMessage());
            \Log::error($e->getTraceAsString());
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de l\'export des transactions admin: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Exporter toutes les transactions du portefeuille système
     */
    public function exportSystemTransactions(Request $request)
    {
        try {
            // Récupérer les paramètres de filtrage
            $currency = $request->input('currency', 'USD');
            $status = $request->input('status', 'all');
            $type = $request->input('type', 'all');
            $search = $request->input('search', '');
            $startDate = $request->input('start_date', '');
            $endDate = $request->input('end_date', '');

            // Récupérer le portefeuille système
            $systemWallet = WalletSystem::first();

            if (!$systemWallet) {
                return response()->json([
                    'success' => false,
                    'message' => 'Portefeuille système non trouvé'
                ], 404);
            }

            // Construire la requête pour les transactions système
            $query = WalletSystemTransaction::with(['walletSystem'])
                ->where('wallet_system_id', $systemWallet->id)
                ->where('currency', $currency);

            // Appliquer les filtres
            if ($status !== 'all') {
                $query->where('status', $status);
            }

            if ($type !== 'all') {
                $query->where('type', $type);
            }

            if (!empty($search)) {
                $query->where(function($q) use ($search) {
                    $q->where('id', 'like', '%' . $search . '%')
                      ->orWhere('type', 'like', '%' . $search . '%')
                      ->orWhere('status', 'like', '%' . $search . '%')
                      ->orWhere('amount', 'like', '%' . $search . '%')
                      ->orWhere('reference', 'like', '%' . $search . '%');
                });
            }

            if (!empty($startDate)) {
                $query->whereDate('created_at', '>=', $startDate);
            }

            if (!empty($endDate)) {
                $query->whereDate('created_at', '<=', $endDate);
            }

            // Récupérer TOUTES les transactions (sans pagination)
            $transactions = $query->orderBy('created_at', 'desc')->get();

            // Formater les transactions
            $formattedTransactions = $transactions->map(function ($transaction) {
                return [
                    'id' => $transaction->id,
                    'amount' => number_format($transaction->amount, 2),
                    'reference' => $transaction->reference,
                    'mouvment' => $transaction->mouvment,
                    'currency' => $transaction->currency,
                    'type' => $transaction->type,
                    'status' => $transaction->status,
                    'metadata' => $transaction->metadata,
                    'created_at' => $transaction->created_at->format('d/m/Y H:i:s')
                ];
            });

            return response()->json([
                'success' => true,
                'transactions' => $formattedTransactions,
                'total' => $formattedTransactions->count(),
                'currency' => $currency,
                'wallet_type' => 'system',
                'filters' => [
                    'status' => $status,
                    'type' => $type,
                    'search' => $search,
                    'start_date' => $startDate,
                    'end_date' => $endDate
                ]
            ]);

        } catch (\Exception $e) {
            \Log::error($e->getMessage());
            \Log::error($e->getTraceAsString());
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de l\'export des transactions système: ' . $e->getMessage()
            ], 500);
        }
    }
} 