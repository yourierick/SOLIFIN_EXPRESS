import React from 'react';
import Welcome from './Welcome';

function App() {
    return <Welcome />;
}

export default App; 