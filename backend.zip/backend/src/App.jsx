import Welcome from './components/Welcome'

function App() {
  return <Welcome />
}

export default App 