<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\WalletSystem;
use App\Models\WalletSystemTransaction;
use App\Models\UserBonusPointHistory;
use App\Models\Pack;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class FinanceController extends Controller
{
    /**
     * Liste des transactions financières avec filtres
     */
    public function index(Request $request)
    {
        $period = $request->get('period', 'month');
        $currency = $request->get('currency', 'USD');
        $type = $request->get('type', 'all');
        $status = $request->get('status', 'completed'); // Par défaut 'completed' au lieu de 'all'
        $page = $request->get('page', 1);
        $perPage = $request->get('per_page', 15);
        
        // Nouveaux filtres
        $mouvment = $request->get('mouvment');
        $search = $request->get('search');
        $packId = $request->get('pack_id');
        $dateStart = $request->get('date_start');
        $dateEnd = $request->get('date_end');
        
        // Définir les dates de début et fin selon la période
        $startDate = $this->getStartDate($period);
        $endDate = Carbon::now();

        // Construire la query de base avec filtrage par devise
        $query = WalletSystemTransaction::whereBetween('created_at', [$startDate, $endDate])
            ->where('currency', $currency);
        
        // Appliquer les filtres
        if ($type !== 'all') {
            $query->where('type', $type);
        }
        
        // Filtre par statut (par défaut 'completed')
        if ($status !== 'all') {
            $query->where('status', $status);
        }

        // Recherche par référence
        if ($request->has('search') && !empty($request->search)) {
            $searchTerm = $request->search;
            $query->where('reference', 'LIKE', '%' . $searchTerm . '%');
        }
        
        // Filtre par mouvement (entrée/sortie)
        if ($mouvment) {
            $query->where('mouvment', $mouvment);
        }
        
        // Filtre par pack (dans les métadonnées)
        if ($packId) {
            $query->where(function($q) use ($packId) {
                // Essayer plusieurs formats pour Pack_ID
                $q->whereJsonContains('metadata->Pack_ID', (string)$packId)
                  ->orWhereJsonContains('metadata->Pack_ID', $packId)
                  ->orWhereJsonContains('metadata->Pack_ID', (int)$packId)
                  // Aussi vérifier si pack_id existe comme clé alternative
                  ->orWhereJsonContains('metadata->pack_id', (string)$packId)
                  ->orWhereJsonContains('metadata->pack_id', $packId)
                  ->orWhereJsonContains('metadata->pack_id', (int)$packId);
            });
        }
        
        // Filtre par date personnalisée
        if ($dateStart) {
            $query->whereDate('created_at', '>=', $dateStart);
        }
        
        if ($dateEnd) {
            $query->whereDate('created_at', '<=', $dateEnd);
        }

        // Tri
        $sortBy = $request->get('sort_by', 'created_at');
        $sortOrder = $request->get('sort_order', 'desc');
        $query->orderBy($sortBy, $sortOrder);

        // Pagination
        $transactions = $query->paginate($perPage, ['*'], 'page', $page);

        return response()->json([
            'data' => $transactions->items(),
            'pagination' => [
                'current_page' => $transactions->currentPage(),
                'last_page' => $transactions->lastPage(),
                'per_page' => $transactions->perPage(),
                'total' => $transactions->total(),
                'from' => $transactions->firstItem(),
                'to' => $transactions->lastItem(),
            ]
        ]);
    }

    /**
     * Statistiques des transactions financières par type et période
     */
    public function financialTransactionsStatistics(Request $request)
    {
        $period = $request->get('period', 'month');
        $currency = $request->get('currency', 'USD');
        $type = $request->get('type', 'all');
        $status = $request->get('status', 'completed'); // Par défaut 'completed' au lieu de 'all'
        
        // Nouveaux filtres
        $mouvment = $request->get('mouvment');
        $search = $request->get('search');
        $packId = $request->get('pack_id');
        $dateStart = $request->get('date_start');
        $dateEnd = $request->get('date_end');
        
        // Définir les dates de début et fin selon la période
        $startDate = $this->getStartDate($period);
        $endDate = Carbon::now();

        // Construire la query de base avec filtrage par devise
        $query = WalletSystemTransaction::whereBetween('created_at', [$startDate, $endDate])
            ->where('currency', $currency);
        
        // Filtrer par type si spécifié
        if ($type !== 'all') {
            $query->where('type', $type);
        }
        
        // Filtre par statut (par défaut 'completed')
        if ($status !== 'all') {
            $query->where('status', $status);
        }
        
        // Filtre par mouvement (entrée/sortie)
        if ($mouvment) {
            $query->where('mouvment', $mouvment);
        }
        
        // Filtre par recherche (référence)
        if ($search) {
            $query->where(function($q) use ($search) {
                $q->where('reference', 'LIKE', "%{$search}%")
                  ->orWhere('id', 'LIKE', "%{$search}%");
            });
        }
        
        // Filtre par pack (dans les métadonnées)
        if ($packId) {
            $query->where(function($q) use ($packId) {
                // Essayer plusieurs formats pour Pack_ID
                $q->whereJsonContains('metadata->Pack_ID', (string)$packId)
                  ->orWhereJsonContains('metadata->Pack_ID', $packId)
                  ->orWhereJsonContains('metadata->Pack_ID', (int)$packId)
                  // Aussi vérifier si pack_id existe comme clé alternative
                  ->orWhereJsonContains('metadata->pack_id', (string)$packId)
                  ->orWhereJsonContains('metadata->pack_id', $packId)
                  ->orWhereJsonContains('metadata->pack_id', (int)$packId);
            });
        }
        
        // Filtre par date personnalisée
        if ($dateStart) {
            $query->whereDate('created_at', '>=', $dateStart);
        }
        
        if ($dateEnd) {
            $query->whereDate('created_at', '<=', $dateEnd);
        }

        // Statistiques de base
        $totalTransactions = $query->count();
        $totalAmount = $query->sum('amount');
        
        $creditQuery = clone $query;
        $debitQuery = clone $query;
        
        $creditAmount = $creditQuery->where('mouvment', 'in')->sum('amount');
        $debitAmount = abs($debitQuery->where('mouvment', 'out')->sum('amount'));
        $creditTransactionsCount = $creditQuery->where('mouvment', 'in')->count();
        $debitTransactionsCount = $debitQuery->where('mouvment', 'out')->count();
        
        // Statistiques par statut
        $statusStats = $query->selectRaw('status, COUNT(*) as count, SUM(amount) as total_amount')
            ->groupBy('status')
            ->get()
            ->keyBy('status');

        return response()->json([
            'total_transactions' => $totalTransactions,
            'total_amount' => $totalAmount,
            'credit_transactions' => $creditTransactionsCount,
            'debit_transactions' => $debitTransactionsCount,
            'credit_amount' => $creditAmount,
            'debit_amount' => $debitAmount,
            'net_amount' => $creditAmount - $debitAmount,
            'status_breakdown' => $statusStats,
            'period' => $period,
            'currency' => $currency,
            'type' => $type,
            'status' => $status, // ✅ AJOUTÉ
        ]);
    }

    /**
     * Export des transactions financières vers Excel
     */
    public function exportFinancialTransactions(Request $request)
    {
        $period = $request->get('period', 'month');
        $currency = $request->get('currency', 'USD');
        $type = $request->get('type', 'all');
        $status = $request->get('status', 'completed');
        $exportType = $request->get('export_type', 'filtered');
        $page = $request->get('page', 1);
        $perPage = $request->get('per_page', 15);
        
        // Nouveaux filtres
        $mouvment = $request->get('mouvment');
        $search = $request->get('search');
        $packId = $request->get('pack_id');
        $dateStart = $request->get('date_start');
        $dateEnd = $request->get('date_end');
        
        // Définir les dates de début et fin selon la période
        $startDate = $this->getStartDate($period);
        $endDate = Carbon::now();

        // Construire la query de base avec filtrage par devise
        $query = WalletSystemTransaction::whereBetween('created_at', [$startDate, $endDate])
            ->where('currency', $currency);
        
        // Appliquer les filtres
        if ($type !== 'all') {
            $query->where('type', $type);
        }
        
        if ($status !== 'all') {
            $query->where('status', $status);
        }

        // Recherche par référence
        if ($request->has('search') && !empty($request->search)) {
            $searchTerm = $request->search;
            $query->where('reference', 'LIKE', '%' . $searchTerm . '%');
        }
        
        // Filtre par mouvement (entrée/sortie)
        if ($mouvment) {
            $query->where('mouvment', $mouvment);
        }
        
        // Filtre par pack (dans les métadonnées)
        if ($packId) {
            $query->where(function($q) use ($packId) {
                // Essayer plusieurs formats pour Pack_ID
                $q->whereJsonContains('metadata->Pack_ID', (string)$packId)
                  ->orWhereJsonContains('metadata->Pack_ID', $packId)
                  ->orWhereJsonContains('metadata->Pack_ID', (int)$packId)
                  // Aussi vérifier si pack_id existe comme clé alternative
                  ->orWhereJsonContains('metadata->pack_id', (string)$packId)
                  ->orWhereJsonContains('metadata->pack_id', $packId)
                  ->orWhereJsonContains('metadata->pack_id', (int)$packId);
            });
        }
        
        // Filtre par date personnalisée
        if ($dateStart) {
            $query->whereDate('created_at', '>=', $dateStart);
        }
        
        if ($dateEnd) {
            $query->whereDate('created_at', '<=', $dateEnd);
        }

        // Appliquer la pagination selon le type d'export
        if ($exportType === 'current_page') {
            $query->offset(($page - 1) * $perPage)->limit($perPage);
        } elseif ($exportType === 'filtered') {
            // Pour l'export filtré, limiter à un nombre raisonnable pour éviter les timeouts
            $query->limit(10000);
        }
        // Pour 'all', on ne limite pas (attention aux performances)

        // Trier par date de création
        $transactions = $query->orderBy('created_at', 'desc')->get();

        // Préparer les données pour l'export (sans la ligne d'en-tête)
        $exportData = [];

        foreach ($transactions as $transaction) {
            $metadata = '';
            if ($transaction->metadata) {
                $metadataArray = [];
                foreach ($transaction->metadata as $key => $value) {
                    if (is_array($value)) {
                        $value = json_encode($value, JSON_UNESCAPED_UNICODE);
                    }
                    $metadataArray[] = "$key: $value";
                }
                $metadata = implode("\n", $metadataArray);
            }

            $exportData[] = [
                'reference' => $transaction->reference ?? 'TRX-' . $transaction->id,
                'type' => $transaction->type ?? '-',
                'mouvment' => $transaction->mouvment === 'in' ? 'Entrée' : ($transaction->mouvment === 'out' ? 'Sortie' : $transaction->mouvment),
                'amount' => $transaction->amount,
                'currency' => $transaction->currency,
                'status' => $this->getStatusLabel($transaction->status),
                'created_at' => $transaction->created_at->format('d/m/Y H:i:s'),
                'metadata' => $metadata
            ];
        }

        return response()->json([
            'data' => $exportData,
            'filename' => 'transactions-financieres-' . $exportType . '-' . date('Y-m-d-H-i-s') . '.xlsx'
        ]);
    }

    /**
     * Obtenir le libellé du statut
     */
    private function getStatusLabel($status)
    {
        $labels = [
            'completed' => 'Complétée',
            'pending' => 'En attente',
            'failed' => 'Échouée',
            'cancelled' => 'Annulée',
        ];
        
        return $labels[$status] ?? $status;
    }

    /**
     * Obtenir la date de début selon la période
     */
    private function getStartDate($period)
    {
        $now = Carbon::now();
        
        switch ($period) {
            case 'day':
                return $now->startOfDay();
            case 'week':
                return $now->startOfWeek();
            case 'month':
                return $now->startOfMonth();
            case 'year':
                return $now->startOfYear();
            default:
                return $now->startOfMonth();
        }
    }

    /**
     * Récupérer les statistiques des transactions regroupées par type
     */
    public function getStatsByType(Request $request)
    {
        try {
            $query = WalletSystemTransaction::query();

            // Filtrer par date de début si spécifiée
            if ($request->has('date_from') && !empty($request->date_from)) {
                $query->whereDate('created_at', '>=', $request->date_from);
            }

            // Filtrer par date de fin si spécifiée
            if ($request->has('date_to') && !empty($request->date_to)) {
                $query->whereDate('created_at', '<=', $request->date_to);
            }

            // Regrouper par type et calculer les totaux (par devise)
            // Debug: Vérifier les devises disponibles dans les transactions
            $availableCurrencies = WalletSystemTransaction::distinct()->pluck('currency');
            \Log::info('Devises disponibles: ' . $availableCurrencies);
            
            // Debug: Compter les transactions par devise (avec différentes variations)
            $countUsd = WalletSystemTransaction::where('currency', 'USD')->count();
            $countCdf = WalletSystemTransaction::where('currency', 'CDF')->count();
            $countCdfLower = WalletSystemTransaction::where('currency', 'cdf')->count();
            $countCdfUpper = WalletSystemTransaction::where('currency', 'Cdf')->count();
            \Log::info('Count USD: ' . $countUsd . ', Count CDF: ' . $countCdf . ', Count cdf: ' . $countCdfLower . ', Count Cdf: ' . $countCdfUpper);
            
            // Debug: Voir quelques transactions CDF récentes
            $recentCdfTransactions = WalletSystemTransaction::where('currency', 'like', '%CD%')->limit(5)->get(['id', 'currency', 'type', 'amount', 'created_at']);
            \Log::info('Transactions CDF récentes: ' . $recentCdfTransactions);

            $statsUsd = $query->where('currency', 'USD')->select('type', 
                DB::raw('COUNT(*) as count'),
                DB::raw('SUM(amount) as total_amount'),
                DB::raw('MIN(created_at) as first_transaction'),
                DB::raw('MAX(created_at) as last_transaction')
            )
            ->groupBy('type')
            ->get();

            // Créer une nouvelle requête pour CDF (pour éviter les conflits)
            $queryCdf = WalletSystemTransaction::query();
            
            // Appliquer les mêmes filtres de date
            if ($request->has('date_from') && !empty($request->date_from)) {
                $queryCdf->whereDate('created_at', '>=', $request->date_from);
            }
            if ($request->has('date_to') && !empty($request->date_to)) {
                $queryCdf->whereDate('created_at', '<=', $request->date_to);
            }
            
            // Essayer avec différentes variations de CDF
            $statsCdf = $queryCdf->whereIn('currency', ['CDF', 'cdf', 'Cdf'])->select('type', 
                DB::raw('COUNT(*) as count'),
                DB::raw('SUM(amount) as total_amount'),
                DB::raw('MIN(created_at) as first_transaction'),
                DB::raw('MAX(created_at) as last_transaction')
            )
            ->groupBy('type')
            ->get();

            \Log::info('Stats CDF: ' . $statsCdf);

            // Calculer le total général par devise
            $totalAmountUsd = $query->where('currency', 'USD')->sum('amount');
            $totalAmountCdf = $queryCdf->whereIn('currency', ['CDF', 'cdf', 'Cdf'])->sum('amount');

            return response()->json([
                'success' => true,
                'data' => [
                    'stats_usd' => $statsUsd,
                    'stats_cdf' => $statsCdf,
                    'total_amount_usd' => $totalAmountUsd,
                    'total_amount_cdf' => $totalAmountCdf
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération des statistiques: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Récupérer les statistiques des transactions par période (jour, semaine, mois)
     */
    public function getStatsByPeriod(Request $request)
    {
        try {
            $period = $request->period ?? 'month';
            $type = $request->type ?? null;
            
            $query = WalletSystemTransaction::query();
            
            // Filtrer par type si spécifié
            if (!empty($type)) {
                $query->where('type', $type);
            }

            // Filtrer par date de début si spécifiée
            if ($request->has('date_from') && !empty($request->date_from)) {
                $query->whereDate('created_at', '>=', $request->date_from);
            }

            // Filtrer par date de fin si spécifiée
            if ($request->has('date_to') && !empty($request->date_to)) {
                $query->whereDate('created_at', '<=', $request->date_to);
            }

            // Grouper par période (par devise)
            switch ($period) {
                case 'day':
                    // Créer des requêtes séparées pour éviter les conflits
                    $queryUsd = WalletSystemTransaction::query();
                    $queryCdf = WalletSystemTransaction::query();
                    
                    // Appliquer les mêmes filtres de date
                    if ($request->has('date_from') && !empty($request->date_from)) {
                        $queryUsd->whereDate('created_at', '>=', $request->date_from);
                        $queryCdf->whereDate('created_at', '>=', $request->date_from);
                    }
                    if ($request->has('date_to') && !empty($request->date_to)) {
                        $queryUsd->whereDate('created_at', '<=', $request->date_to);
                        $queryCdf->whereDate('created_at', '<=', $request->date_to);
                    }
                    
                    $statsUsd = $queryUsd->where('currency', 'USD')->select(
                        DB::raw('DATE(created_at) as period'),
                        DB::raw('COUNT(*) as count'),
                        DB::raw('SUM(amount) as total_amount')
                    )
                    ->groupBy('period')
                    ->orderBy('period')
                    ->get();

                    $statsCdf = $queryCdf->whereIn('currency', ['CDF', 'cdf', 'Cdf'])->select(
                        DB::raw('DATE(created_at) as period'),
                        DB::raw('COUNT(*) as count'),
                        DB::raw('SUM(amount) as total_amount')
                    )
                    ->groupBy('period')
                    ->orderBy('period')
                    ->get();
                    break;
                
                case 'week':
                    // Créer des requêtes séparées pour éviter les conflits
                    $queryUsd = WalletSystemTransaction::query();
                    $queryCdf = WalletSystemTransaction::query();
                    
                    // Appliquer les mêmes filtres de date
                    if ($request->has('date_from') && !empty($request->date_from)) {
                        $queryUsd->whereDate('created_at', '>=', $request->date_from);
                        $queryCdf->whereDate('created_at', '>=', $request->date_from);
                    }
                    if ($request->has('date_to') && !empty($request->date_to)) {
                        $queryUsd->whereDate('created_at', '<=', $request->date_to);
                        $queryCdf->whereDate('created_at', '<=', $request->date_to);
                    }
                    
                    $statsUsd = $queryUsd->where('currency', 'USD')->select(
                        DB::raw('YEARWEEK(created_at) as period'),
                        DB::raw('COUNT(*) as count'),
                        DB::raw('SUM(amount) as total_amount'),
                        DB::raw('MIN(DATE(created_at)) as start_date'),
                        DB::raw('MAX(DATE(created_at)) as end_date')
                    )
                    ->groupBy('period')
                    ->orderBy('period')
                    ->get();

                    $statsCdf = $queryCdf->whereIn('currency', ['CDF', 'cdf', 'Cdf'])->select(
                        DB::raw('YEARWEEK(created_at) as period'),
                        DB::raw('COUNT(*) as count'),
                        DB::raw('SUM(amount) as total_amount'),
                        DB::raw('MIN(DATE(created_at)) as start_date'),
                        DB::raw('MAX(DATE(created_at)) as end_date')
                    )
                    ->groupBy('period')
                    ->orderBy('period')
                    ->get();
                    break;
                
                case 'month':
                default:
                    // Créer des requêtes séparées pour éviter les conflits
                    $queryUsd = WalletSystemTransaction::query();
                    $queryCdf = WalletSystemTransaction::query();
                    
                    // Appliquer les mêmes filtres de date
                    if ($request->has('date_from') && !empty($request->date_from)) {
                        $queryUsd->whereDate('created_at', '>=', $request->date_from);
                        $queryCdf->whereDate('created_at', '>=', $request->date_from);
                    }
                    if ($request->has('date_to') && !empty($request->date_to)) {
                        $queryUsd->whereDate('created_at', '<=', $request->date_to);
                        $queryCdf->whereDate('created_at', '<=', $request->date_to);
                    }
                    
                    $statsUsd = $queryUsd->where('currency', 'USD')->select(
                        DB::raw('DATE_FORMAT(created_at, "%Y-%m") as period'),
                        DB::raw('COUNT(*) as count'),
                        DB::raw('SUM(amount) as total_amount')
                    )
                    ->groupBy('period')
                    ->orderBy('period')
                    ->get();

                    $statsCdf = $queryCdf->whereIn('currency', ['CDF', 'cdf', 'Cdf'])->select(
                        DB::raw('DATE_FORMAT(created_at, "%Y-%m") as period'),
                        DB::raw('COUNT(*) as count'),
                        DB::raw('SUM(amount) as total_amount')
                    )
                    ->groupBy('period')
                    ->orderBy('period')
                    ->get();
                    break;
            }

            return response()->json([
                'success' => true,
                'data' => [
                    'stats_usd' => $statsUsd,
                    'stats_cdf' => $statsCdf,
                    'period_type' => $period
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération des statistiques par période: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Récupérer les types de transactions disponibles
     */
    public function getTransactionTypes()
    {
        try {
            $types = WalletSystemTransaction::select('type')
                ->distinct()
                ->pluck('type');

            return response()->json([
                'success' => true,
                'data' => $types
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération des types de transactions: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Récupérer le solde actuel du système
     */
    public function getSystemBalance()
    {
        try {
            $walletSystem = WalletSystem::first();
            
            if (!$walletSystem) {
                return response()->json([
                    'success' => false,
                    'message' => 'Aucun système de portefeuille trouvé'
                ], 404);
            }

            return response()->json([
                'success' => true,
                'data' => [
                    'balance_usd' => $walletSystem->balance_usd,
                    'balance_cdf' => $walletSystem->balance_cdf,
                    'total_in_usd' => $walletSystem->total_in_usd,
                    'total_in_cdf' => $walletSystem->total_in_cdf,
                    'total_out_usd' => $walletSystem->total_out_usd,
                    'total_out_cdf' => $walletSystem->total_out_cdf,
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération du solde du système: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Récupérer le résumé des finances
     */
    public function getSummary(Request $request)
    {
        try {
            // Période par défaut: dernier mois
            $startDate = $request->date_from ? Carbon::parse($request->date_from) : Carbon::now()->subMonth();
            $endDate = $request->date_to ? Carbon::parse($request->date_to) : Carbon::now();

            // Récupérer le solde actuel
            $walletSystem = WalletSystem::first();
            
            if (!$walletSystem) {
                return response()->json([
                    'success' => false,
                    'message' => 'Aucun système de portefeuille trouvé'
                ], 404);
            }

            // Récupérer les statistiques par type pour la période
            $statsByType = WalletSystemTransaction::whereBetween('created_at', [$startDate, $endDate])
                ->select('type', 
                    DB::raw('COUNT(*) as count'),
                    DB::raw('SUM(amount) as total_amount')
                )
                ->where('status', 'completed')
                ->groupBy('type')
                ->get();

            // Récupérer le total des entrées et sorties pour la période (par devise)
            $totalInUsd = WalletSystemTransaction::whereBetween('created_at', [$startDate, $endDate])
                ->where('mouvment', 'in')
                ->where('status', 'completed')
                ->where('currency', 'USD')
                ->sum('amount');

            $totalInCdf = WalletSystemTransaction::whereBetween('created_at', [$startDate, $endDate])
                ->where('mouvment', 'in')
                ->where('status', 'completed')
                ->where('currency', 'CDF')
                ->sum('amount');

            $totalOutUsd = WalletSystemTransaction::whereBetween('created_at', [$startDate, $endDate])
                ->where('mouvment', 'out')->where('status', 'completed')
                ->where('currency', 'USD')
                ->sum('amount');

            $totalOutCdf = WalletSystemTransaction::whereBetween('created_at', [$startDate, $endDate])
                ->where('mouvment', 'out')->where('status', 'completed')
                ->where('currency', 'CDF')
                ->sum('amount');

            // Récupérer les statistiques par type pour la période (par devise)
            $statsByTypeUsd = WalletSystemTransaction::whereBetween('created_at', [$startDate, $endDate])
                ->select('type', 
                    DB::raw('COUNT(*) as count'),
                    DB::raw('SUM(amount) as total_amount')
                )
                ->where('status', 'completed')
                ->where('currency', 'USD')
                ->groupBy('type')
                ->get();

            $statsByTypeCdf = WalletSystemTransaction::whereBetween('created_at', [$startDate, $endDate])
                ->select('type', 
                    DB::raw('COUNT(*) as count'),
                    DB::raw('SUM(amount) as total_amount')
                )
                ->where('status', 'completed')
                ->where('currency', 'CDF')
                ->groupBy('type')
                ->get();

            // Récupérer le nombre de transactions par jour pour la période (par devise)
            $transactionsByDayUsd = WalletSystemTransaction::whereBetween('created_at', [$startDate, $endDate])
                ->select(
                    DB::raw('DATE(created_at) as date'),
                    DB::raw('COUNT(*) as count'),
                    DB::raw('SUM(amount) as total_amount')
                )
                ->where('currency', 'USD')
                ->groupBy('date')
                ->orderBy('date')
                ->get();

            $transactionsByDayCdf = WalletSystemTransaction::whereBetween('created_at', [$startDate, $endDate])
                ->select(
                    DB::raw('DATE(created_at) as date'),
                    DB::raw('COUNT(*) as count'),
                    DB::raw('SUM(amount) as total_amount')
                )
                ->where('currency', 'CDF')
                ->groupBy('date')
                ->orderBy('date')
                ->get();

            return response()->json([
                'success' => true,
                'data' => [
                    'current_balance_usd' => $walletSystem->balance_usd,
                    'current_balance_cdf' => $walletSystem->balance_cdf,
                    'total_in_usd_all_time' => $walletSystem->total_in_usd,
                    'total_in_cdf_all_time' => $walletSystem->total_in_cdf,
                    'total_out_usd_all_time' => $walletSystem->total_out_usd,
                    'total_out_cdf_all_time' => $walletSystem->total_out_cdf,
                    'period_total_in_usd' => $totalInUsd,
                    'period_total_in_cdf' => $totalInCdf,
                    'period_total_out_usd' => $totalOutUsd,
                    'period_total_out_cdf' => $totalOutCdf,
                    'stats_by_type_usd' => $statsByTypeUsd,
                    'stats_by_type_cdf' => $statsByTypeCdf,
                    'transactions_by_day_usd' => $transactionsByDayUsd,
                    'transactions_by_day_cdf' => $transactionsByDayCdf,
                    'period' => [
                        'start' => $startDate->format('Y-m-d'),
                        'end' => $endDate->format('Y-m-d')
                    ]
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération du résumé des finances: ' . $e->getMessage()
            ], 500);
        }
    }


    /**
     * Exporter les transactions financières
     * 
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function exportFinanceTransactions(Request $request)
    {
        try {
            $query = WalletSystemTransaction::query()
                ->with(['walletSystem'])
                ->orderBy('created_at', 'desc');

            // Appliquer les mêmes filtres que la fonction index
            if ($request->has('type') && !empty($request->type)) {
                $query->where('type', $request->type);
            }

            if ($request->has('status') && !empty($request->status)) {
                $query->where('status', $request->status);
            }

            if ($request->has('date_from') && !empty($request->date_from)) {
                $query->whereDate('created_at', '>=', $request->date_from);
            }

            if ($request->has('date_to') && !empty($request->date_to)) {
                $query->whereDate('created_at', '<=', $request->date_to);
            }

            if ($request->has('currency') && !empty($request->currency)) {
                $query->where('currency', $request->currency);
            }

            if ($request->has('user_id') && !empty($request->user_id)) {
                $query->where('user_id', $request->user_id);
            }

            if ($request->has('pack_id') && !empty($request->pack_id)) {
                $query->where('pack_id', $request->pack_id);
            }

            if ($request->has('search') && !empty($request->search)) {
                $search = $request->search;
                $query->where(function($q) use ($search) {
                    $q->where('reference', 'like', "%{$search}%")
                      ->orWhere('description', 'like', "%{$search}%")
                      ->orWhereHas('user', function($subQuery) use ($search) {
                          $subQuery->where('name', 'like', "%{$search}%")
                                  ->orWhere('email', 'like', "%{$search}%");
                      });
                });
            }

            // Récupérer toutes les transactions correspondantes
            $transactions = $query->get();

            return response()->json([
                'success' => true,
                'data' => $transactions,
                'count' => $transactions->count()
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de l\'exportation des transactions financières: ' . $e->getMessage()
            ], 500);
        }
    }
}
