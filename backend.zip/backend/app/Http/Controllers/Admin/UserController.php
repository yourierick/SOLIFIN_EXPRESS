<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Pack;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\DB;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use App\Models\UserPack;
use App\Models\Commission;
use App\Models\Role;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use App\Services\WalletService;


class UserController extends BaseController
{
    /**
     * Affiche la liste des utilisateurs.
     */
    public function index(Request $request)
    {
        try {
            $query = User::query()
                ->select('users.*') // Sélectionner explicitement les colonnes de la table users
                ->where('is_admin', false)
                ->withCount('referrals')
                ->with(['grade', 'packs' => function ($query) {
                    $query->select('user_packs.id', 'user_packs.user_id', 'user_packs.pack_id');
                }]);

            //\Log::info('Nombre total d\'utilisateurs avant filtres: ' . $query->count());

            // Appliquer les filtres
            if ($request->filled('search')) {
                $search = $request->input('search');
                $query->where(function ($q) use ($search) {
                    $q->where('users.name', 'like', "%{$search}%")
                      ->orWhere('users.email', 'like', "%{$search}%");
                });
            }

            if ($request->filled('status')) {
                $status = $request->input('status');
                $query->where('users.status', $status);
            }

            if ($request->filled('has_pack')) {
                $hasPack = $request->input('has_pack');
                if ($hasPack == '1') {
                    $query->has('packs');
                } elseif ($hasPack == '0') {
                    $query->doesntHave('packs');
                }
            }

            if ($request->filled('grade_id')) {
                $gradeId = $request->input('grade_id');
                $query->where('users.grade_id', $gradeId);
            }

            $users = $query->paginate(10);

            foreach ($users as $user) {
                $user->picture = $user->picture ? asset('storage/' . $user->picture) : null;
            }

            return response()->json([
                'success' => true,
                'data' => $users
            ]);

        } catch (\Exception $e) {
            \Log::error('Erreur dans UserController@index: ' . $e->getMessage());
            \Log::error('Stack trace: ' . $e->getTraceAsString());
            return response()->json([
                'success' => false,
                'message' => 'Une erreur est survenue lors de la récupération des utilisateurs: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Affiche un utilisateur spécifique.
     * 
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show(Request $request, $id)
    {
        try {
            $user = User::with(['packs', 'grade', 'referrals'])
                ->withCount('referrals')
                ->findOrFail($id);

            // Récupérer les informations de connexion de l'utilisateur
            $session = DB::table('sessions')
                ->where('user_id', $id)
                ->orderBy('id', 'desc')
                ->first();
                
            $user->last_ip_address = $session ? $session->ip_address : null;
            
            // Extraire des informations plus lisibles du user-agent
            if ($session && $session->user_agent) {
                $userAgent = $session->user_agent;
                
                // Détecter le navigateur
                $browser = "Inconnu";
                if (strpos($userAgent, 'Edg') !== false) {
                    $browser = "Microsoft Edge";
                } elseif (strpos($userAgent, 'Chrome') !== false) {
                    $browser = "Google Chrome";
                } elseif (strpos($userAgent, 'Firefox') !== false) {
                    $browser = "Mozilla Firefox";
                } elseif (strpos($userAgent, 'Safari') !== false) {
                    $browser = "Safari";
                } elseif (strpos($userAgent, 'Opera') !== false || strpos($userAgent, 'OPR') !== false) {
                    $browser = "Opera";
                }
                
                // Détecter le système d'exploitation
                $os = "Inconnu";
                if (strpos($userAgent, 'Windows') !== false) {
                    $os = "Windows";
                } elseif (strpos($userAgent, 'Mac') !== false) {
                    $os = "macOS";
                } elseif (strpos($userAgent, 'Android') !== false) {
                    $os = "Android";
                } elseif (strpos($userAgent, 'iOS') !== false || strpos($userAgent, 'iPhone') !== false || strpos($userAgent, 'iPad') !== false) {
                    $os = "iOS";
                } elseif (strpos($userAgent, 'Linux') !== false) {
                    $os = "Linux";
                }
                
                // Détecter le type d'appareil
                $device = "Desktop";
                if (strpos($userAgent, 'Mobile') !== false || strpos($userAgent, 'Android') !== false || strpos($userAgent, 'iPhone') !== false) {
                    $device = "Mobile";
                } elseif (strpos($userAgent, 'Tablet') !== false || strpos($userAgent, 'iPad') !== false) {
                    $device = "Tablet";
                }
                
                $user->browser = $browser;
                $user->os = $os;
                $user->device_type = $device;
            } else {
                $user->browser = null;
                $user->os = null;
                $user->device_type = null;
            }

            // Récupérer le wallet de l'utilisateur à détailler
            $userWallet = Wallet::where('user_id', $id)->first();
            $wallet = $userWallet ? [
                'balance_usd' => $userWallet->balance_usd,
                'balance_cdf' => $userWallet->balance_cdf,
                'points' => $userWallet->points,
                'total_earned_usd' => $userWallet->total_earned_usd,
                'total_earned_cdf' => $userWallet->total_earned_cdf,
                'total_withdrawn_usd' => $userWallet->total_withdrawn_usd,
                'total_withdrawn_cdf' => $userWallet->total_withdrawn_cdf,
            ] : null;

            $transactions = [];
            if ($userWallet) {
                // Récupérer les transactions du wallet avec pagination et filtres
                $query = WalletTransaction::with('wallet')->where('wallet_id', $userWallet->id);
                
                // Appliquer les filtres si présents dans la requête
                if ($request->has('type')) {
                    $query->where('type', $request->type);
                }
                
                if ($request->has('status')) {
                    $query->where('status', $request->status);
                }
            
                if ($request->has('currency') && !empty($request->currency)) {
                    $query->where('currency', $request->currency);
                }
            
                if ($request->has('date_from')) {
                    $query->whereDate('created_at', '>=', $request->date_from);
                }
            
                if ($request->has('date_to')) {
                    $query->whereDate('created_at', '<=', $request->date_to);
                }
            
                if ($request->has('amount_min')) {
                    $query->where('amount', '>=', $request->amount_min);
                }
            
                if ($request->has('amount_max')) {
                    $query->where('amount', '<=', $request->amount_max);
                }
            
                if ($request->has('search')) {
                    $search = $request->search;
                    $query->where(function($q) use ($search) {
                        $q->where('id', 'like', "%{$search}%")
                          ->orWhere('type', 'like', "%{$search}%")
                          ->orWhere('status', 'like', "%{$search}%")
                          ->orWhere('reference', 'like', "%{$search}%");
                    });
                }
                // Pagination
            $perPage = $request->input('per_page', 25);
            $page = $request->input('page', 1);
            
            // Obtenir le nombre total de transactions après filtrage
            $totalTransactions = $query->count();
            
            // Obtenir les transactions paginées
            $transactionsData = $query->orderBy('created_at', 'desc')
                ->skip(($page - 1) * $perPage)
                ->take($perPage)
                ->get()
                ->map(function ($transaction) {
                    return [
                        'id' => $transaction->id,
                        'amount' => $transaction->amount,
                        'currency' => $transaction->currency,
                        'reference' => $transaction->reference,
                        'type' => $transaction->type,
                        'mouvment' => $transaction->mouvment,
                        'type_raw' => $transaction->type, // Pour le filtrage
                        'status' => $transaction->status,
                        'metadata' => $transaction->metadata,
                        'created_at' => $transaction->created_at->format('d/m/Y H:i:s'),
                        'created_at_raw' => $transaction->created_at->toIso8601String() // Pour le tri
                    ];
                });
                
                // Préparer la réponse paginée
                $transactions = [
                    'data' => $transactionsData,
                    'total' => $totalTransactions,
                    'per_page' => $perPage,
                    'current_page' => $page,
                    'last_page' => ceil($totalTransactions / $perPage)
                ];
            }
            
            
            // Pagination pour les packs
            $packPerPage = $request->input('per_page', 25);
            $packPage = $request->input('page', 1);
            
            // Construire la requête pour les packs avec pagination
            $packsQuery = UserPack::with(['pack', 'sponsor'])
                ->where('user_id', $id);
            
            // Obtenir le nombre total de packs après filtrage
            $totalPacks = $packsQuery->count();
            
            // Obtenir les packs paginés
            $userPacksData = $packsQuery
                ->skip(($packPage - 1) * $packPerPage)
                ->take($packPerPage)
                ->get()
                ->map(function ($userPack) {
                    $data = $userPack->toArray();
                    if ($userPack->sponsor) {
                        $data['sponsor_info'] = [
                            'name' => $userPack->sponsor->name,
                            'email' => $userPack->sponsor->email,
                            'phone' => $userPack->sponsor->phone,
                        ];
                    }
                    
                    // Récupérer le nombre de filleuls par génération pour ce pack
                    $referralsByGeneration = [0, 0, 0, 0]; // Initialiser un tableau pour 4 générations
                    
                    // Filleuls de première génération (directs)
                    $referralsByGeneration[0] = UserPack::where('sponsor_id', $userPack->user_id)
                        ->where('pack_id', $userPack->pack_id)
                        ->where('payment_status', 'completed')
                        ->count();
                    
                    // Pour les générations suivantes, nous utilisons une requête récursive avec CTE (Common Table Expression)
                    if ($referralsByGeneration[0] > 0) {
                        $referralsData = \DB::select("
                            WITH RECURSIVE filleuls AS (
                                -- Première génération (directs)
                                SELECT up1.user_id, up1.sponsor_id, 1 as generation
                                FROM user_packs up1
                                WHERE up1.sponsor_id = ? AND up1.pack_id = ? AND up1.payment_status = 'completed'
                                
                                UNION ALL
                                
                                -- Générations suivantes (2 à 4)
                                SELECT up2.user_id, up2.sponsor_id, f.generation + 1
                                FROM user_packs up2
                                INNER JOIN filleuls f ON up2.sponsor_id = f.user_id
                                WHERE up2.pack_id = ? AND up2.payment_status = 'completed' AND f.generation < 4
                            )
                            SELECT generation, COUNT(user_id) as total_filleuls
                            FROM filleuls
                            WHERE generation > 1
                            GROUP BY generation
                            ORDER BY generation
                        ", [$userPack->user_id, $userPack->pack_id, $userPack->pack_id]);
                        
                        // Remplir le tableau avec les résultats de la requête
                        foreach ($referralsData as $referral) {
                            // Les générations commencent à 1 dans la requête SQL, mais à 0 dans notre tableau
                            $index = $referral->generation - 1;
                            if ($index < 4) {
                                $referralsByGeneration[$index] = $referral->total_filleuls;
                            }
                        }
                    }
                    
                    $data['referrals_by_generation'] = $referralsByGeneration;
                    return $data;
                });

            // Préparer la réponse paginée pour les packs
            $userPacks = [
                'data' => $userPacksData,
                'total' => $totalPacks,
                'per_page' => $packPerPage,
                'current_page' => $packPage,
                'last_page' => ceil($totalPacks / $packPerPage)
            ];
            
            \Log::info("Packs paginés: " . count($userPacksData) . " sur " . $totalPacks . " (page " . $packPage . ", per_page " . $packPerPage . ")");

            if ($user->picture) {
                $user->profile_picture = asset('storage/' . $user->picture);
            }
            // Récupérer tous les packs actifs de l'utilisateur
            $utilisateur = User::find($id);
            $user_packs = $utilisateur->packs()
                ->wherePivot('payment_status', 'completed')
                ->wherePivot('status', 'active')
                ->get();

            return response()->json([
                'success' => true,
                'data' => [
                    'user' => $user,
                    'wallet' => $wallet,
                    'transactions' => $transactions,
                    'packs' => $userPacks,
                ]
            ]);

        } catch (\Exception $e) {
            \Log::error('Erreur dans UserController@show: ' . $e->getMessage());
            \Log::error('Erreur dans UserController@show: ' . $e->getTraceAsString());
            return response()->json([
                'success' => false,
                'message' => 'Une erreur est survenue lors de la récupération des détails de l\'utilisateur'
            ], 500);
        }
    }

    /**
     * Récupère la liste des filleuls d'un utilisateur
     */
    public function referrals(User $user, Request $request)
    {
        try {
            $packId = $request->input('pack_id');
            $referrals = $user->getReferrals($packId);
            
            return response()->json([
                'success' => true,
                'data' => $referrals,
                'message' => 'Liste des filleuls récupérée avec succès'
            ]);
        } catch (\Exception $e) {
            Log::error('Erreur dans UserController@referrals: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération des filleuls',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function edit(User $user)
    {
        return response()->json($user);
    }

    public function update(Request $request, User $user)
    {
        try {
            $validated = $request->validate([
                'name' => ['required', 'string', 'max:255'],
                'email' => ['required', 'email', Rule::unique('users')->ignore($user->id)],
                'phone' => ['nullable', 'string', 'max:20'],
                'address' => ['nullable', 'string', 'max:255'],
                'status' => ['required', 'string', 'in:active,inactive,suspended'],
                'password' => ['nullable', 'min:8', 'confirmed'],
                'is_admin' => ['boolean'],
            ]);

            // Mettre à jour les informations de base
            $user->fill($validated);

            // Mettre à jour le mot de passe si fourni
            if (!empty($validated['password'])) {
                $user->password = Hash::make($validated['password']);
            }

            // Gérer explicitement is_admin car il peut être false
            if ($request->has('is_admin')) {
                // Empêcher la désactivation du dernier admin
                if (!$request->boolean('is_admin') && $user->is_admin && User::where('is_admin', true)->count() === 1) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Impossible de retirer les droits du dernier administrateur'
                    ], 422);
                }
                $user->is_admin = $request->boolean('is_admin');
            }

            $user->save();

            return response()->json([
                'success' => true,
                'message' => 'Utilisateur mis à jour avec succès',
                'data' => $user
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur de validation',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            \Log::error('Erreur dans UserController@update: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Une erreur est survenue lors de la mise à jour de l\'utilisateur'
            ], 500);
        }
    }

    public function destroy(User $user)
    {
        try {
            DB::beginTransaction();
            
            $user->delete(); // Cette méthode appellera notre méthode delete() personnalisée

            DB::commit();
            
            return response()->json([
                'success' => true,
                'message' => 'Utilisateur supprimé avec succès'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la suppression de l\'utilisateur',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Toggle user status between active and inactive
     */
    public function toggleStatus($userId)
    {
        try {
            $user = User::find($userId);
            
            // Empêcher la désactivation du dernier administrateur
            if ($user->is_admin && User::where('is_admin', true)->count() == 1) {
                return response()->json([
                    'success' => false,
                    'message' => 'Impossible de désactiver le dernier administrateur'
                ], 422);
            }

            // Toggle le statut
            $user->status = $user->status === 'active' ? 'inactive' : 'active';
            $user->save();

            return response()->json([
                'success' => true,
                'message' => 'Statut de l\'utilisateur mis à jour avec succès',
                'data' => $user
            ]);

        } catch (\Exception $e) {
            \Log::error('Erreur dans UserController@toggleStatus: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Une erreur est survenue lors de la mise à jour du statut'
            ], 500);
        }
    }

    public function network(User $user)
    {
        try {
            $referrals = $user->referrals()
                ->with(['packs', 'wallet'])
                ->paginate(15);

            $networkStats = [
                'direct_referrals' => $user->referrals()->count(),
                'total_network' => $user->getAllDownlines()->count(),
                'active_referrals' => $user->referrals()->where('status', 'active')->count(),
                'total_commissions' => $user->wallet->transactions()
                    ->where('type', 'credit')
                    ->sum('amount'),
            ];

            return response()->json([
                'success' => true,
                'data' => [
                    'referrals' => $referrals,
                    'networkStats' => $networkStats
                ],
                'message' => 'Réseau de l\'utilisateur récupéré avec succès'
            ]);
        } catch (\Exception $e) {
            Log::error('Erreur dans UserController@network: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération du réseau',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function transactions(User $user)
    {
        try {
            $transactions = $user->wallet->transactions()
                ->latest()
                ->paginate(15);

            return response()->json([
                'success' => true,
                'data' => $transactions,
                'message' => 'Transactions de l\'utilisateur récupérées avec succès'
            ]);
        } catch (\Exception $e) {
            Log::error('Erreur dans UserController@transactions: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération des transactions',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Réinitialise le mot de passe d'un utilisateur
     */
    public function resetPassword($id, Request $request)
    {
        try {
            $request->validate([
                'new_password' => 'required|string|min:8',
                'admin_password' => 'required|string',
            ]);

            // Vérifier le mot de passe de l'administrateur
            $admin = auth()->user();
            if (!Hash::check($request->admin_password, $admin->password)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Mot de passe administrateur incorrect'
                ], 401);
            }

            // Trouver l'utilisateur et réinitialiser son mot de passe
            $user = User::findOrFail($id);
            $user->password = Hash::make($request->new_password);
            $user->save();

            // Journaliser l'action
            Log::info("Mot de passe réinitialisé pour l'utilisateur ID: {$id} par l'administrateur ID: {$admin->id}");

            return response()->json([
                'success' => true,
                'message' => 'Mot de passe réinitialisé avec succès'
            ]);
        } catch (\Exception $e) {
            Log::error('Erreur dans UserController@resetPassword: ' . $e->getMessage());
            \Log::error('Erreur dans UserController@resetPassword: '. $e->getTraceAsString());
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la réinitialisation du mot de passe',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    //Détails d'un utilisateur
    //récupérer les filleuls d'un pack
    public function getPackReferrals(Request $request, $id)
    {
        try {
            $pack = Pack::findOrFail($id);
            
            // Pour l'admin, on doit pouvoir spécifier l'utilisateur
            $userId = $request->query('user_id');
            if (!$userId) {
                return response()->json([
                    'success' => false,
                    'message' => 'ID utilisateur requis'
                ], 400);
            }
            
            $user = User::findOrFail($userId);
            
            $userPack = UserPack::where('user_id', $userId)
                ->where('pack_id', $pack->id)
                ->first();

            if (!$userPack) {
                return response()->json([
                    'success' => false,
                    'message' => 'Pack non trouvé pour cet utilisateur'
                ], 404);
            }

            $allGenerations = [];
            
            // Première génération (niveau 1)
            $level1Referrals = UserPack::with(['user', 'sponsor', 'pack'])
                ->where('sponsor_id', $userId)
                ->where('pack_id', $pack->id)
                ->get()
                ->map(function ($referral) use ($userId, $pack) {
                    $commissions_usd = Commission::where('user_id', $userId)
                        ->where('currency', 'USD')
                        ->where('source_user_id', $referral->user_id)
                        ->where('pack_id', $pack->id)
                        ->where('status', "completed")
                        ->sum('amount');

                    $commissions_cdf = Commission::where('user_id', $userId)
                        ->where('currency', 'CDF')
                        ->where('source_user_id', $referral->user_id)
                        ->where('pack_id', $pack->id)
                        ->where('status', "completed")
                        ->sum('amount');
                    return [
                        'id' => $referral->user->id ?? null,
                        'name' => $referral->user->name ?? 'N/A',
                        'purchase_date' => optional($referral->purchase_date)->format('d/m/Y'),
                        'pack_status' => $referral->status ?? 'inactive',
                        'total_commission_usd' => $commissions_usd ?? 0,
                        'total_commission_cdf' => $commissions_cdf ?? 0,
                        'sponsor_id' => $referral->sponsor_id,
                        'referral_code' => $referral->referral_code ?? 'N/A',
                        'pack_name' => $referral->referral_pack_name ?? 'N/A',
                        'pack_price' => $referral->pack->price ?? 0,
                        'expiry_date' => optional($referral->expiry_date)->format('d/m/Y')
                    ];
                });
            $allGenerations[] = $level1Referrals;

            // Générations 2 à 4
            for ($level = 2; $level <= 4; $level++) {
                $currentGeneration = collect();
                $previousGeneration = $allGenerations[$level - 2];

                foreach ($previousGeneration as $parent) {
                    $children = UserPack::with(['user', 'sponsor', 'pack'])
                        ->where('sponsor_id', $parent['id'])
                        ->where('pack_id', $pack->id)
                        ->get()
                        ->map(function ($referral) use ($parent, $userId, $pack) {
                            //calcul du total de commission générée par ce filleul pour cet utilisateur.
                            $commissions_usd = Commission::where('user_id', $userId)
                                ->where('currency', 'USD')
                                ->where('source_user_id', $referral->user_id)
                                ->where('pack_id', $pack->id)
                                ->where('status', "completed")
                                ->sum('amount');

                            $commissions_cdf = Commission::where('user_id', $userId)
                                ->where('currency', 'CDF')
                                ->where('source_user_id', $referral->user_id)
                                ->where('pack_id', $pack->id)
                                ->where('status', "completed")
                                ->sum('amount');
                            return [
                                'id' => $referral->user->id ?? null,
                                'name' => $referral->user->name ?? 'N/A',
                                'purchase_date' => optional($referral->purchase_date)->format('d/m/Y'),
                                'pack_status' => $referral->status ?? 'inactive',
                                'total_commission_usd' => $commissions_usd ?? 0,
                                'total_commission_cdf' => $commissions_cdf ?? 0,
                                'sponsor_id' => $referral->sponsor_id,
                                'sponsor_name' => $parent['name'] ?? 'N/A',
                                'referral_code' => $referral->referral_code ?? 'N/A',
                                'pack_name' => $referral->pack->name ?? 'N/A',
                                'pack_price' => $referral->pack->price ?? 0,
                                'expiry_date' => optional($referral->expiry_date)->format('d/m/Y')
                            ];
                        });
                    $currentGeneration = $currentGeneration->concat($children);
                }
                $allGenerations[] = $currentGeneration;
            }

            return response()->json([
                'success' => true,
                'data' => $allGenerations
            ]);
        } catch (\Exception $e) {
            \Log::error('Erreur lors de la récupération des filleuls: ' . $e->getTraceAsString());
            
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération des filleuls: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Récupère les statistiques détaillées d'un pack pour un utilisateur spécifié
     * 
     * @param Request $request
     * @param int $id ID du pack
     * @return \Illuminate\Http\JsonResponse
     */
    public function getDetailedPackStats(Request $request, $id)
    {
        try {
            $userpack = UserPack::with('pack')->find($id);
            $pack = $userpack->pack;
            
            // Pour l'admin, on doit pouvoir spécifier l'utilisateur
            $userId = $request->query('user_id');
            if (!$userId) {
                return response()->json([
                    'success' => false,
                    'message' => 'ID utilisateur requis'
                ], 400);
            }
            
            $user = User::findOrFail($userId);
            
            $userPack = UserPack::where('user_id', $userId)
                ->where('pack_id', $pack->id)
                ->first();

            if (!$userPack) {
                return response()->json([
                    'success' => false,
                    'message' => 'Pack non trouvé pour cet utilisateur'
                ], 404);
            }

            // Récupérer tous les filleuls (toutes générations confondues)
            $allReferrals = [];
            $totalReferralsCount = 0;
            $referralsByGeneration = [0, 0, 0, 0]; // Compteur pour chaque génération
            $commissionsByGenerationUSD = [0, 0, 0, 0]; // Commissions USD pour chaque génération
            $commissionsByGenerationCDF = [0, 0, 0, 0]; // Commissions CDF pour chaque génération
            $activeReferralsCount = 0;
            $inactiveReferralsCount = 0;
            $totalCommissionUSD = 0;
            $totalCommissionCDF = 0;
            $failedCommissionUSD = 0;
            $failedCommissionCDF = 0;

            // Récupérer les filleuls de première génération
            $firstGenReferrals = UserPack::with(['user', 'pack'])
                ->where('sponsor_id', $userId)
                ->where('pack_id', $pack->id)
                ->get();

            $referralsByGeneration[0] = $firstGenReferrals->count();
            $totalReferralsCount += $referralsByGeneration[0];
            
            // Compter les actifs/inactifs de première génération
            foreach ($firstGenReferrals as $referral) {
                if ($referral->status === 'active') {
                    $activeReferralsCount++;
                } else {
                    $inactiveReferralsCount++;
                }
                
                // Ajouter à la liste complète des filleuls
                $allReferrals[] = [
                    'id' => $referral->user->id,
                    'name' => $referral->user->name,
                    'generation' => 1,
                    'purchase_date' => $referral->purchase_date,
                    'expiry_date' => $referral->expiry_date,
                    'status' => $referral->status,
                    'pack_name' => $referral->pack->name
                ];
            }

            // Récupérer les commissions de première génération
            $gen1Commissions = Commission::where('user_id', $userId)
                ->where('pack_id', $pack->id)
                ->where('level', 1)
                ->get();
                
            $commissionsByGenerationUSD[0] = $gen1Commissions->where('status', 'completed')->where('currency', 'USD')->sum('amount');
            $commissionsByGenerationCDF[0] = $gen1Commissions->where('status', 'completed')->where('currency', 'CDF')->sum('amount');
            $totalCommissionUSD += $commissionsByGenerationUSD[0];
            $totalCommissionCDF += $commissionsByGenerationCDF[0];
            $failedCommissionUSD += $gen1Commissions->where('status', 'failed')->where('currency', 'USD')->sum('amount');
            $failedCommissionCDF += $gen1Commissions->where('status', 'failed')->where('currency', 'CDF')->sum('amount');

            // Récupérer les filleuls et commissions des générations 2 à 4
            $currentGenReferrals = $firstGenReferrals->pluck('user_id')->toArray();
            
            for ($generation = 2; $generation <= 4; $generation++) {
                $nextGenReferrals = [];
                
                foreach ($currentGenReferrals as $sponsorId) {
                    $referrals = UserPack::with(['user', 'pack'])
                        ->where('sponsor_id', $sponsorId)
                        ->where('pack_id', $pack->id)
                        ->get();
                        
                    foreach ($referrals as $referral) {
                        $nextGenReferrals[] = $referral->user_id;
                        
                        // Compter par statut
                        if ($referral->status === 'active') {
                            $activeReferralsCount++;
                        } else {
                            $inactiveReferralsCount++;
                        }
                        
                        // Ajouter à la liste complète des filleuls
                        $allReferrals[] = [
                            'id' => $referral->user->id,
                            'name' => $referral->user->name,
                            'generation' => $generation,
                            'purchase_date' => $referral->purchase_date,
                            'expiry_date' => $referral->expiry_date,
                            'status' => $referral->status,
                            'pack_name' => $referral->pack->name
                        ];
                    }
                    
                    $referralsByGeneration[$generation-1] += $referrals->count();
                    $totalReferralsCount += $referrals->count();
                }
                
                // Récupérer les commissions pour cette génération
                $genCommissions = Commission::where('user_id', $userId)
                    ->where('pack_id', $pack->id)
                    ->where('level', $generation)
                    ->get();
                    
                $commissionsByGenerationUSD[$generation-1] = $genCommissions->where('status', 'completed')->where('currency', 'USD')->sum('amount');
                $commissionsByGenerationCDF[$generation-1] = $genCommissions->where('status', 'completed')->where('currency', 'CDF')->sum('amount');
                $totalCommissionUSD += $commissionsByGenerationUSD[$generation-1];
                $totalCommissionCDF += $commissionsByGenerationCDF[$generation-1];
                $failedCommissionUSD += $genCommissions->where('status', 'failed')->where('currency', 'USD')->sum('amount');
                $failedCommissionCDF += $genCommissions->where('status', 'failed')->where('currency', 'CDF')->sum('amount');
                
                $currentGenReferrals = $nextGenReferrals;
            }

            // Récupérer les données pour les graphiques d'évolution
            $sixMonthsAgo = now()->subMonths(6);
            
            // Inscriptions mensuelles
            $monthlySignups = [];
            for ($i = 0; $i < 6; $i++) {
                $month = now()->subMonths($i);
                $count = collect($allReferrals)
                    ->filter(function ($referral) use ($month) {
                        return $referral['purchase_date'] && 
                               date('Y-m', strtotime($referral['purchase_date'])) === $month->format('Y-m');
                    })
                    ->count();
                    
                $monthlySignups[$month->format('Y-m')] = $count;
            }
            
            // Commissions mensuelles
            $monthlyCommissionsUSD = [];
            $monthlyCommissionsCDF = [];
            for ($i = 0; $i < 6; $i++) {
                $month = now()->subMonths($i);
                $startOfMonth = $month->copy()->startOfMonth();
                $endOfMonth = $month->copy()->endOfMonth();
                
                $amountUSD = Commission::where('user_id', $userId)
                    ->where('pack_id', $pack->id)
                    ->where('status', 'completed')
                    ->where('currency', 'USD')
                    ->whereBetween('created_at', [$startOfMonth, $endOfMonth])
                    ->sum('amount');
                    
                $amountCDF = Commission::where('user_id', $userId)
                    ->where('pack_id', $pack->id)
                    ->where('status', 'completed')
                    ->where('currency', 'CDF')
                    ->whereBetween('created_at', [$startOfMonth, $endOfMonth])
                    ->sum('amount');
                    
                $monthlyCommissionsUSD[$month->format('Y-m')] = $amountUSD;
                $monthlyCommissionsCDF[$month->format('Y-m')] = $amountCDF;
            }
            
            // Trouver le top filleul (celui qui a recruté le plus de personnes)
            $topReferral = null;
            $maxRecruits = 0;
            
            foreach ($firstGenReferrals as $referral) {
                $recruitCount = UserPack::where('sponsor_id', $referral->user_id)
                    ->where('pack_id', $pack->id)
                    ->count();
                    
                if ($recruitCount > $maxRecruits) {
                    $maxRecruits = $recruitCount;
                    
                    // Calculer les commissions générées par ce referral
                    $referralCommissionsUSD = Commission::where('user_id', $userId)
                        ->where('pack_id', $pack->id)
                        ->where('source_user_id', $referral->user_id)
                        ->where('currency', 'USD')
                        ->where('status', 'completed')
                        ->sum('amount');
                        
                    $referralCommissionsCDF = Commission::where('user_id', $userId)
                        ->where('pack_id', $pack->id)
                        ->where('source_user_id', $referral->user_id)
                        ->where('currency', 'CDF')
                        ->where('status', 'completed')
                        ->sum('amount');
                    
                    $topReferral = [
                        'id' => $referral->user->id,
                        'name' => $referral->user->name,
                        'recruit_count' => $recruitCount,
                        'commission_usd' => $referralCommissionsUSD,
                        'commission_cdf' => $referralCommissionsCDF
                    ];
                }
            }

            // Récupérer les derniers paiements reçus
            $latestPayments = Commission::with('source_user')
                ->where('user_id', $userId)
                ->where('pack_id', $pack->id)
                ->where('status', 'completed')
                ->orderBy('created_at', 'desc')
                ->take(10)
                ->get()
                ->map(function ($commission) {
                    return [
                        'id' => $commission->id,
                        'amount' => $commission->amount,
                        'currency' => $commission->currency,
                        'date' => $commission->created_at->format('d/m/Y'),
                        'source' => $commission->source_user->name ?? 'Inconnu',
                        'status' => $commission->status,
                        'level' => $commission->level
                    ];
                });

            // Modifier la structure des données pour les filleuls (limité à 10)
            $latestReferrals = collect($allReferrals)
                ->sortByDesc('purchase_date')
                ->take(10)
                ->map(function ($referral) {
                    $validityMonths = $referral['purchase_date'] && $referral['expiry_date'] 
                        ? $referral['purchase_date']->diffInMonths($referral['expiry_date'])
                        : 0;
                    
                    return [
                        'id' => $referral['id'],
                        'name' => $referral['name'],
                        'generation' => $referral['generation'],
                        'pack_name' => $referral['pack_name'],
                        'purchase_date' => $referral['purchase_date'] ? $referral['purchase_date']->format('d/m/Y') : 'N/A',
                        'expiry_date' => $referral['expiry_date'] ? $referral['expiry_date']->format('d/m/Y') : 'N/A',
                        'validity_months' => $validityMonths,
                        'status' => $referral['status']
                    ];
                })
                ->values()
                ->toArray();

            // Modifier la structure pour tous les filleuls
            $allReferrals = collect($allReferrals)
                ->map(function ($referral) {
                    $validityMonths = $referral['purchase_date'] && $referral['expiry_date'] 
                        ? $referral['purchase_date']->diffInMonths($referral['expiry_date'])
                        : 0;
                    
                    return [
                        'id' => $referral['id'],
                        'name' => $referral['name'],
                        'generation' => $referral['generation'],
                        'pack_name' => $referral['pack_name'],
                        'purchase_date' => $referral['purchase_date'] ? $referral['purchase_date']->format('d/m/Y') : 'N/A',
                        'expiry_date' => $referral['expiry_date'] ? $referral['expiry_date']->format('d/m/Y') : 'N/A',
                        'validity_months' => $validityMonths,
                        'status' => $referral['status']
                    ];
                })
                ->values()
                ->toArray();
           
            return response()->json([
                'success' => true,
                'data' => [
                    'general_stats' => [
                        'total_referrals' => $totalReferralsCount,
                        'referrals_by_generation' => $referralsByGeneration,
                        'active_referrals' => $activeReferralsCount,
                        'inactive_referrals' => $inactiveReferralsCount,
                        'total_commission_usd' => $totalCommissionUSD,
                        'total_commission_cdf' => $totalCommissionCDF,
                        'failed_commission_usd' => $failedCommissionUSD,
                        'failed_commission_cdf' => $failedCommissionCDF,
                        'commissions_by_generation_usd' => $commissionsByGenerationUSD,
                        'commissions_by_generation_cdf' => $commissionsByGenerationCDF,
                    ],
                    'progression' => [
                        'monthly_signups' => $monthlySignups,
                        'monthly_commissions_usd' => $monthlyCommissionsUSD,
                        'monthly_commissions_cdf' => $monthlyCommissionsCDF,
                        'top_referral' => $topReferral
                    ],
                    'latest_referrals' => $latestReferrals,
                    'financial_info' => [
                        'total_commission_usd' => $totalCommissionUSD,
                        'total_commission_cdf' => $totalCommissionCDF,
                        'latest_payments' => $latestPayments
                    ],
                    'all_referrals' => $allReferrals,
                ]
            ]);
        } catch (\Exception $e) {
            \Log::error('Erreur lors de la récupération des statistiques détaillées: ' . $e->getMessage());
            \Log::error('Stack trace: ' . $e->getTraceAsString());
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération des statistiques détaillées: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Toggle le statut d'un pack utilisateur (active/inactive)
     *
     * @param Request $request
     * @param int $packId ID du pack utilisateur
     * @return \Illuminate\Http\JsonResponse
     */
    public function togglePackStatus(Request $request, $packId)
    {
        try {
            // Trouver le pack utilisateur
            $userPack = UserPack::findOrFail($packId);
            
            // Vérifier que le pack existe
            if (!$userPack) {
                return response()->json([
                    'success' => false,
                    'message' => 'Pack utilisateur non trouvé'
                ], 404);
            }
            
            // Inverser le statut
            $newStatus = $userPack->status === 'active' ? 'inactive' : 'active';
            $userPack->status = $newStatus;
            $userPack->save();
            
            // Log l'action
            Log::info("Pack utilisateur ID {$packId} statut changé à {$newStatus} par admin ID " . $request->user()->id);
            
            return response()->json([
                'success' => true,
                'message' => 'Statut du pack mis à jour avec succès',
                'data' => [
                    'id' => $userPack->id,
                    'status' => $userPack->status
                ]
            ]);
        } catch (\Exception $e) {
            Log::error('Erreur lors du changement de statut du pack: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors du changement de statut du pack: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Fonctions pour les administrateurs
     
     * Créer un nouvel administrateur avec un rôle spécifique
     * Cette méthode est réservée aux super administrateurs
     * 
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function createAdmin(Request $request)
    {
        try {
            // Valider les données
            $validated = $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|max:255|unique:users',
                'password' => 'required|string|min:8',
                'phone' => 'required|string',
                'address' => 'required|string',
                'role_id' => 'required|exists:roles,id',
                'pays' => 'required|string',
                'province' => 'required|string',
                'ville' => 'required|string',
                'sexe' => 'required|string',
            ]);
            
            DB::beginTransaction();

            $role = Role::find($validated['role_id']);
            
            // Créer l'utilisateur administrateur
            $admin = User::create([
                'name' => $validated['name'],
                'email' => $validated['email'],
                'password' => Hash::make($validated['password']),
                'phone' => $validated['phone'] ?? null,
                'role_id' => $role->id,
                'address' => $validated['address'] ?? null,
                'pays' => $validated['pays'] ?? null,
                'province' => $validated['province'] ?? null,
                'ville' => $validated['ville'] ?? null,
                'sexe' => $validated['sexe'] === "masculin" ? "homme" : "femme",
                'status' => 'active',
                'is_admin' => true,
            ]);

            $users = User::all();

            do {
                $account_id = 'ADM-' . rand(1, 100) . "-" . Str::random(4);
            } while ($users->contains('account_id', $account_id));
            
            $admin->account_id = $account_id;
            $admin->save();

            $walletService = new WalletService();
            $walletService->createUserWallet($admin->id);

            DB::commit();
            
            return response()->json([
                'success' => true,
                'message' => 'Administrateur créé avec succès',
                'admin' => [
                    'id' => $admin->id,
                    'name' => $admin->name,
                    'email' => $admin->email,
                    'role' => $role->nom,
                    'permissions' => $role->permissions->pluck('nom'),
                ]
            ], 201);
            
        } catch (\Exception $e) {
            \Log::error('Erreur lors de la création de l\'administrateur: ' . $e->getMessage());
            \Log::error($e->getTraceAsString());
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la création de l\'administrateur',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function getRoles()
    {
        try {
            $roles = Role::where("slug", '!=', "user")->where("slug", '!=', "super-admin")->get();
            \Log::info("ici");
            return response()->json([
                'success' => true,
                'data' => $roles
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Rôles non trouvés'
            ], 404);
        }
    }

    public function getAdmin($id)
    {
        try {
            $admin = User::with('roleRelation')->findOrFail($id);
            return response()->json([
                'success' => true,
                'data' => $admin
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Administrateur non trouvé'
            ], 404);
        }
    }

    public function updateAdmin(Request $request, $id)
    {
        try {
            $user = User::findOrFail($id);
            
            // Valider les données
            $validated = $request->validate([
                'name' => 'required|string|max:255',
                'email' => ['required', 'string', 'email', 'max:255', Rule::unique('users')->ignore($user->id)],
                'password' => 'nullable|string|min:8|confirmed',
                'phone' => 'nullable|string',
                'address' => 'nullable|string',
                'pays' => 'nullable|string',
                'province' => 'nullable|string',
                'ville' => 'nullable|string',
                'sexe' => 'nullable|string',
            ]);
            
            DB::beginTransaction();
            
            // Mettre à jour l'utilisateur
            $user->fill($validated);
            
            // Mettre à jour le mot de passe si fourni
            if (!empty($validated['password'])) {
                $user->password = Hash::make($validated['password']);
            }
            
            $user->save();
            
            DB::commit();

            // Récupérer le rôle pour l'inclure dans la réponse
            $role = Role::where("slug", "gestionnaire")->first();    
            
            return response()->json([
                'success' => true,
                'message' => 'Administrateur mis à jour avec succès',
                'admin' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $role->nom,
                    'permissions' => $role->permissions->pluck('nom'),
                ]
            ]);
            
        } catch (\Exception $e) {
            \Log::error('Erreur lors de la mise à jour de l\'administrateur : ' . $e->getMessage());
            \Log::error($e->getTraceAsString());
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la mise à jour de l\'administrateur',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function deleteAdmin($id)
    {
        try {
            $user = User::findOrFail($id);

            $superAdmins = User::whereHas('roleRelation', function ($query) {
                $query->where('nom', '=', 'super-admin');
            })->get();
            
            if ($superAdmins->count() === 1 && $superAdmins->first()->id === $user->id) {
                return response()->json([
                    'success' => false,
                    'message' => 'Impossible de supprimer le dernier super-admin'
                ], 422);
            }

            // Supprimer la picture de l'utilisateur
            if ($user->picture && Storage::disk('public')->exists($user->picture)) {
                Storage::disk('public')->delete($user->picture);
            }
            
            // Supprimer l'utilisateur
            $user->delete();  
            
            return response()->json([
                'success' => true,
                'message' => 'Administrateur supprimé avec succès'
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la suppression de l\'administrateur',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function getAdmins()
    {
        try {
            // Récupérer tous les administrateurs
            $admins = User::with('roleRelation')->where('is_admin', true)->where('role_id', '!=', Role::where("slug", "super-admin")->first()->id)->get();

            foreach ($admins as $admin) {
                $admin->picture = $admin->picture ? asset('storage/' . $admin->picture) : null;
                
                // Récupérer les informations de connexion de l'administrateur
                $session = DB::table('sessions')
                    ->where('user_id', $admin->id)
                    ->orderBy('id', 'desc')
                    ->first();
                    
                $admin->last_ip_address = $session ? $session->ip_address : null;
                
                // Extraire des informations plus lisibles du user-agent
                if ($session && $session->user_agent) {
                    $userAgent = $session->user_agent;
                    
                    // Détecter le navigateur
                    $browser = "Inconnu";
                    if (strpos($userAgent, 'Edg') !== false) {
                        $browser = "Microsoft Edge";
                    } elseif (strpos($userAgent, 'Chrome') !== false) {
                        $browser = "Google Chrome";
                    } elseif (strpos($userAgent, 'Firefox') !== false) {
                        $browser = "Mozilla Firefox";
                    } elseif (strpos($userAgent, 'Safari') !== false) {
                        $browser = "Safari";
                    } elseif (strpos($userAgent, 'Opera') !== false || strpos($userAgent, 'OPR') !== false) {
                        $browser = "Opera";
                    }
                    
                    // Détecter le système d'exploitation
                    $os = "Inconnu";
                    if (strpos($userAgent, 'Windows') !== false) {
                        $os = "Windows";
                    } elseif (strpos($userAgent, 'Mac') !== false) {
                        $os = "macOS";
                    } elseif (strpos($userAgent, 'Android') !== false) {
                        $os = "Android";
                    } elseif (strpos($userAgent, 'iOS') !== false || strpos($userAgent, 'iPhone') !== false || strpos($userAgent, 'iPad') !== false) {
                        $os = "iOS";
                    } elseif (strpos($userAgent, 'Linux') !== false) {
                        $os = "Linux";
                    }
                    
                    // Détecter le type d'appareil
                    $device = "Desktop";
                    if (strpos($userAgent, 'Mobile') !== false || strpos($userAgent, 'Android') !== false || strpos($userAgent, 'iPhone') !== false) {
                        $device = "Mobile";
                    } elseif (strpos($userAgent, 'Tablet') !== false || strpos($userAgent, 'iPad') !== false) {
                        $device = "Tablet";
                    }
                    
                    $admin->browser = $browser;
                    $admin->os = $os;
                    $admin->device_type = $device;
                } else {
                    $admin->browser = null;
                    $admin->os = null;
                    $admin->device_type = null;
                }
            }
            
            return response()->json([
                'success' => true,
                'admins' => $admins
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération des administrateurs',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function toggleAdminStatus($userId)
    {
        try {
            $user = User::find($userId);
            
            // Empêcher la désactivation du dernier administrateur
            if ($user->is_admin && User::where('is_admin', true)->count() == 1) {
                return response()->json([
                    'success' => false,
                    'message' => 'Impossible de désactiver le dernier administrateur'
                ], 422);
            }

            // Toggle le statut
            $user->status = $user->status === 'active' ? 'inactive' : 'active';
            $user->save();

            return response()->json([
                'success' => true,
                'message' => 'Statut de l\'administrateur mis à jour avec succès',
                'data' => $user
            ]);

        } catch (\Exception $e) {
            \Log::error('Erreur dans UserController@toggleAdminStatus: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Une erreur est survenue lors de la mise à jour du statut'
            ], 500);
        }
    }

    /**
     * Get dashboard statistics for users
     * 
     * @return \Illuminate\Http\JsonResponse
     */
    public function getDashboardStats()
    {
        try {
            // Statistiques générales
            $totalUsers = User::where('is_admin', false)->count();
            $activeUsers = User::where('is_admin', false)->where('status', 'active')->count();
            $inactiveUsers = User::where('is_admin', false)->where('status', 'inactive')->count();
            $trialUsers = User::where('is_admin', false)->where('status', 'trial')->count();
            
            // Taux d'activité (utilisateurs avec au moins un pack actif)
            $usersWithActivePacks = UserPack::where('status', 'active')
                ->distinct('user_id')
                ->count('user_id');
            
            $activityRate = $totalUsers > 0 ? round(($usersWithActivePacks / $totalUsers) * 100, 1) : 0;
            
            // Statistiques d'inscription par période
            $today = now()->startOfDay();
            $thisWeekStart = now()->startOfWeek();
            $thisMonthStart = now()->startOfMonth();
            $thisYearStart = now()->startOfYear();
            
            $todayRegistrations = User::where('is_admin', false)
                ->where('created_at', '>=', $today)
                ->count();
                
            $weekRegistrations = User::where('is_admin', false)
                ->where('created_at', '>=', $thisWeekStart)
                ->count();
                
            $monthRegistrations = User::where('is_admin', false)
                ->where('created_at', '>=', $thisMonthStart)
                ->count();
                
            $yearRegistrations = User::where('is_admin', false)
                ->where('created_at', '>=', $thisYearStart)
                ->count();
            
            // Tendances (comparaison avec période précédente)
            $lastWeekStart = now()->startOfWeek()->subWeek(1);
            $lastWeekEnd = now()->startOfWeek();
            $lastMonthStart = now()->startOfMonth()->subMonth(1);
            $lastMonthEnd = now()->startOfMonth();
            $lastYearStart = now()->startOfYear()->subYear(1);
            $lastYearEnd = now()->startOfYear();
            
            $lastWeekRegistrations = User::where('is_admin', false)
                ->whereBetween('created_at', [$lastWeekStart, $lastWeekEnd])
                ->count();
                
            $lastMonthRegistrations = User::where('is_admin', false)
                ->whereBetween('created_at', [$lastMonthStart, $lastMonthEnd])
                ->count();
                
            $lastYearRegistrations = User::where('is_admin', false)
                ->whereBetween('created_at', [$lastYearStart, $lastYearEnd])
                ->count();
            
            // Calcul des tendances
            $weekTrend = $lastWeekRegistrations > 0 
                ? round((($weekRegistrations - $lastWeekRegistrations) / $lastWeekRegistrations) * 100, 1)
                : ($weekRegistrations > 0 ? 100 : 0);
                
            $monthTrend = $lastMonthRegistrations > 0 
                ? round((($monthRegistrations - $lastMonthRegistrations) / $lastMonthRegistrations) * 100, 1)
                : ($monthRegistrations > 0 ? 100 : 0);
                
            $yearTrend = $lastYearRegistrations > 0 
                ? round((($yearRegistrations - $lastYearRegistrations) / $lastYearRegistrations) * 100, 1)
                : ($yearRegistrations > 0 ? 100 : 0);
            
            return response()->json([
                'success' => true,
                'data' => [
                    'total_users' => $totalUsers,
                    'active_users' => $activeUsers,
                    'inactive_users' => $inactiveUsers,
                    'trial_users' => $trialUsers,
                    'users_with_active_packs' => $usersWithActivePacks,
                    'activity_rate' => $activityRate,
                    'registrations' => [
                        'today' => $todayRegistrations,
                        'week' => $weekRegistrations,
                        'month' => $monthRegistrations,
                        'year' => $yearRegistrations,
                    ],
                    'trends' => [
                        'week' => [
                            'value' => $weekTrend,
                            'direction' => $weekTrend > 0 ? 'up' : ($weekTrend < 0 ? 'down' : 'stable')
                        ],
                        'month' => [
                            'value' => $monthTrend,
                            'direction' => $monthTrend > 0 ? 'up' : ($monthTrend < 0 ? 'down' : 'stable')
                        ],
                        'year' => [
                            'value' => $yearTrend,
                            'direction' => $yearTrend > 0 ? 'up' : ($yearTrend < 0 ? 'down' : 'stable')
                        ]
                    ]
                ]
            ]);
            
        } catch (\Exception $e) {
            \Log::error('Erreur dans UserController@getDashboardStats: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Une erreur est survenue lors de la récupération des statistiques'
            ], 500);
        }
    }
}