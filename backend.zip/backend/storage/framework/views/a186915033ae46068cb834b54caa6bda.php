<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Facture SOLIFIN - <?php echo e($invoiceNumber); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f8f9fa;
        }
        
        .invoice-container {
            max-width: 800px;
            margin: 20px auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            position: relative;
        }
        
        .header::after {
            content: '';
            position: absolute;
            bottom: -20px;
            left: 0;
            right: 0;
            height: 20px;
            background: white;
            border-radius: 20px 20px 0 0;
        }
        
        .company-info {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }
        
        .company-name {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .company-tagline {
            font-size: 14px;
            opacity: 0.9;
        }
        
        .invoice-details {
            text-align: right;
        }
        
        .invoice-number {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .invoice-date {
            font-size: 14px;
            opacity: 0.9;
        }
        
        .content {
            padding: 40px 30px;
        }
        
        .section {
            margin-bottom: 30px;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #667eea;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 2px solid #667eea;
        }
        
        .two-columns {
            display: flex;
            gap: 40px;
        }
        
        .column {
            flex: 1;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: 120px 1fr;
            gap: 10px;
        }
        
        .info-label {
            font-weight: 600;
            color: #666;
        }
        
        .info-value {
            color: #333;
        }
        
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        .items-table th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #667eea;
            border-bottom: 2px solid #667eea;
        }
        
        .items-table td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .items-table tr:last-child td {
            border-bottom: none;
        }
        
        .text-right {
            text-align: right;
        }
        
        .text-center {
            text-align: center;
        }
        
        .totals-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }
        
        .totals-grid {
            display: grid;
            grid-template-columns: 1fr 200px;
            gap: 10px;
        }
        
        .total-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
        }
        
        .total-label {
            font-weight: 600;
        }
        
        .total-value {
            font-weight: 700;
            color: #667eea;
        }
        
        .grand-total {
            border-top: 2px solid #667eea;
            padding-top: 15px;
            margin-top: 10px;
            font-size: 18px;
        }
        
        .subscription-info {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
        }
        
        .subscription-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .subscription-details {
            display: flex;
            justify-content: space-between;
        }
        
        .payment-info {
            background: #e8f5e8;
            border: 1px solid #4caf50;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
        }
        
        .payment-status {
            color: #2e7d32;
            font-weight: 600;
        }
        
        .footer {
            background: #f8f9fa;
            padding: 30px;
            text-align: center;
            border-top: 1px solid #eee;
        }
        
        .footer-info {
            margin-bottom: 15px;
            color: #666;
        }
        
        .footer-note {
            font-size: 12px;
            color: #999;
            font-style: italic;
        }
        
        .watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-45deg);
            font-size: 120px;
            color: rgba(102, 126, 234, 0.1);
            font-weight: 700;
            z-index: -1;
        }
    </style>
</head>
<body>
    <div class="invoice-container">
        <div class="header">
            <div class="company-info">
                <div>
                    <div class="company-name">SOLIFIN</div>
                    <div class="company-tagline">Solution Express Pour l'Indépendance Financière</div>
                </div>
                <div class="invoice-details">
                    <div class="invoice-number">Facture <?php echo e($invoiceNumber); ?></div>
                    <div class="invoice-date">Date: <?php echo e($invoiceDate); ?></div>
                </div>
            </div>
        </div>
        
        <div class="content">
            <div class="two-columns">
                <div class="column">
                    <div class="section">
                        <div class="section-title">Informations Client</div>
                        <div class="info-grid">
                            <div class="info-label">Nom:</div>
                            <div class="info-value"><?php echo e($customer['name']); ?></div>
                            <div class="info-label">Email:</div>
                            <div class="info-value"><?php echo e($customer['email']); ?></div>
                            <div class="info-label">Téléphone:</div>
                            <div class="info-value"><?php echo e($customer['phone']); ?></div>
                        </div>
                    </div>
                </div>
                
                <div class="column">
                    <div class="section">
                        <div class="section-title">Informations Entreprise</div>
                        <div class="info-grid">
                            <div class="info-label">Nom:</div>
                            <div class="info-value"><?php echo e($company['name']); ?></div>
                            <div class="info-label">Adresse:</div>
                            <div class="info-value"><?php echo e($company['address']); ?></div>
                            <div class="info-label">Email:</div>
                            <div class="info-value"><?php echo e($company['email']); ?></div>
                            <div class="info-label">Téléphone:</div>
                            <div class="info-value"><?php echo e($company['phone']); ?></div>
                            <div class="info-label">RCCM:</div>
                            <div class="info-value"><?php echo e($company['rccm']); ?></div>
                            <div class="info-label">IDNAT:</div>
                            <div class="info-value"><?php echo e($company['idnat']); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">Détails de la Facture</div>
                <table class="items-table">
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th class="text-center">Quantité</th>
                            <th class="text-right">Prix Unitaire</th>
                            <th class="text-right">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item['description']); ?></td>
                            <td class="text-center"><?php echo e($item['quantity']); ?></td>
                            <td class="text-right"><?php echo e(number_format($item['unit_price'], 2)); ?> <?php echo e($item['currency']); ?></td>
                            <td class="text-right"><?php echo e(number_format($item['total'], 2)); ?> <?php echo e($item['currency']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <div class="totals-section">
                    <div class="totals-grid">
                        <div></div>
                        <div>
                            <div class="total-row">
                                <span class="total-label">Sous-total:</span>
                                <span class="total-value"><?php echo e(number_format($totals['subtotal'], 2)); ?> <?php echo e($totals['currency']); ?></span>
                            </div>
                            <div class="total-row">
                                <span class="total-label">Frais:</span>
                                <span class="total-value"><?php echo e(number_format($totals['tax'], 2)); ?> <?php echo e($totals['currency']); ?></span>
                            </div>
                            <div class="total-row grand-total">
                                <span class="total-label">Total:</span>
                                <span class="total-value"><?php echo e(number_format($totals['total'], 2)); ?> <?php echo e($totals['currency']); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="subscription-info">
                <div class="subscription-title">📅 Informations d'Abonnement</div>
                <div class="subscription-details">
                    <div>
                        <strong>Début:</strong> <?php echo e($subscription['start_date']); ?><br>
                        <strong>Fin:</strong> <?php echo e($subscription['end_date']); ?><br>
                        <strong>Durée:</strong> <?php echo e($subscription['duration']); ?>

                    </div>
                </div>
            </div>
            
            <div class="payment-info">
                <div class="payment-status">
                    ✅ <?php echo e($payment['status']); ?> - <?php echo e($payment['method']); ?>

                </div>
                <div>Date de paiement: <?php echo e($payment['date']); ?></div>
            </div>
        </div>
        
        <div class="footer">
            <div class="footer-info">
                <strong><?php echo e($company['name']); ?></strong> | <?php echo e($company['address']); ?><br>
                <?php echo e($company['email']); ?> | <?php echo e($company['phone']); ?> | <?php echo e($company['website']); ?>

            </div>
            <div class="footer-note">
                Merci pour votre confiance! Cette facture est générée automatiquement et est valide sans signature.
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\SOLIFIN\backend\resources\views/invoices/pack.blade.php ENDPATH**/ ?>